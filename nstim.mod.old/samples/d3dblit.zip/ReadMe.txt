Direct3D Sprite Drawing Demo

This demo accompanies the GameDev (www.gamedev.net) article:

   Dissecting Sprites in Direct3D

It contains code and example usage for the described functions, and 
illustrates the described bugs.

----------------------------------------------------------------------

You should have all these files

  d3dblit.cpp
  d3dblit.dsp
  d3dblit.dsw
  readme.txt
  sprites.bmp

This demo was written in Visual C++ 6.0.

The graphics in "sprites.bmp" were created by Ari Feldman
(www.arifeldman.com).

Thanks,

R. Parker (parkmuse@hotmail.com)
10 March, 2002
